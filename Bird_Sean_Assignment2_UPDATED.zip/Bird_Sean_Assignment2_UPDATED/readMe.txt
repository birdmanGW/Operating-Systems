simpleShell.c

-This program can be compiled using the following updated gcc version:

Configured with: --prefix=/Library/Developer/CommandLineTools/usr --with-gxx-include-dir=/usr/include/c++/4.2.1
Apple LLVM version 7.0.0 (clang-700.0.72)
Target: x86_64-apple-darwin14.4.0
Thread model: posix

Shell works and was a lot of fun to code!